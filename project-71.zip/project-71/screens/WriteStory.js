import * as React from 'react';
import {StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import { TextInput } from ' react-native-gesture-handler';
import { Header } from 'react-native-elements';
import db from '../config'
import firebase from 'firebase';

export default class WriteStory extends React.Component{
  render(){
    return (
      <Text>
        WriteStory
      </Text>

      <TouchableOpacity style = {styles.submitButton} onPress = {this.submitButton}>
      <Text style = {styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    )
  }
}