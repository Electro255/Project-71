import * as React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createAppContainer } from 'react-navigation';
import ReadStory from './screens/ReadStory';
import WriteStory from './screens/WriteStory';

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}

const TabNavigator = createBottomTabNavigator(
  {
    WriteStory: WriteStory,
    ReadStory: ReadStory,
  },
  {
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: () => {
        const routeName = navigation.state.routeName;
        if (routeName === 'ReadStory') {
          return (
            <Image
              source={require('./images/read.png')}
              style={{ width: 40, height: 40 }}></Image>
          );
        } else if (routeName === 'WriteStory') {
          return (
            <Image
              source={require('./images/write.png')}
              style={{ width: 40, height: 40 }}></Image>
          );
        }
      },
    }),
  }
);

const AppContainer = createAppContainer(TabNavigator);
